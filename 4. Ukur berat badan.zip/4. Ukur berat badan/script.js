document.getElementById('bmi-link').addEventListener('click', function() {
    showSection('bmi-section');
});

document.getElementById('fibonacci-link').addEventListener('click', function() {
    showSection('fibonacci-section');
});

document.getElementById('geometry-link').addEventListener('click', function() {
    showSection('geometry-section');
});

document.getElementById('bmi-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const height = parseFloat(document.getElementById('height').value) / 100;
    const weight = parseFloat(document.getElementById('weight').value);
    const bmi = (weight / (height * height)).toFixed(2);
    let result = '';

    if (bmi < 18.5) {
        result = 'BMI Anda adalah ' + bmi + ' (Kurus)';
    } else if (bmi < 24.9) {
        result = 'BMI Anda adalah ' + bmi + ' (Ideal)';
    } else if (bmi < 29.9) {
        result = 'BMI Anda adalah ' + bmi + ' (Berat badan berlebih)';
    } else {
        result = 'BMI Anda adalah ' + bmi + ' (Obesitas)';
    }

    document.getElementById('bmi-result').textContent = result;
});

document.getElementById('fibonacci-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const count = parseInt(document.getElementById('fibonacci-input').value);
    let fibonacci = [0, 1];
    for (let i = 2; i < count; i++) {
        fibonacci[i] = fibonacci[i - 1] + fibonacci[i - 2];
    }
    document.getElementById('fibonacci-result').textContent = fibonacci.slice(0, count).join(', ');
});

document.getElementById('shape').addEventListener('change', function() {
    const shape = document.getElementById('shape').value;
    const inputDimensions = document.getElementById('input-dimensions');
    inputDimensions.innerHTML = '';

    if (shape === 'tabung') {
        inputDimensions.innerHTML = `
            <label for="radius">Jari-jari (cm):</label>
            <input type="number" id="radius" name="radius" required>
            
            <label for="height">Tinggi (cm):</label>
            <input type="number" id="height-tabung" name="height" required>
        `;
    } else if (shape === 'bola') {
        inputDimensions.innerHTML = `
            <label for="radius">Jari-jari (cm):</label>
            <input type="number" id="radius" name="radius" required>
        `;
    } else if (shape === 'limas') {
        inputDimensions.innerHTML = `
            <label for="base-length">Panjang Alas (cm):</label>
            <input type="number" id="base-length" name="base-length" required>
            
            <label for="base-width">Lebar Alas (cm):</label>
            <input type="number" id="base-width" name="base-width" required>
            
            <label for="height">Tinggi (cm):</label>
            <input type="number" id="height-limas" name="height" required>
        `;
    }
});

document.getElementById('geometry-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const shape = document.getElementById('shape').value;
    let result = '';

    if (shape === 'tabung') {
        const radius = parseFloat(document.getElementById('radius').value);
        const height = parseFloat(document.getElementById('height-tabung').value);
        const area = (Math.PI * radius * radius).toFixed(2);
        const volume = (Math.PI * radius * radius * height).toFixed(2);
        result = `Luas Alas: ${area} cm², Volume: ${volume} cm³`;
    } else if (shape === 'bola') {
        const radius = parseFloat(document.getElementById('radius').value);
        const area = (4 * Math.PI * radius * radius).toFixed(2);
        const volume = ((4/3) * Math.PI * radius * radius * radius).toFixed(2);
        result = `Luas Permukaan: ${area} cm², Volume: ${volume} cm³`;
    } else if (shape === 'limas') {
        const baseLength = parseFloat(document.getElementById('base-length').value);
        const baseWidth = parseFloat(document.getElementById('base-width').value);
        const height = parseFloat(document.getElementById('height-limas').value);
        const area = (baseLength * baseWidth).toFixed(2);
        const volume = ((1/3) * baseLength * baseWidth * height).toFixed(2);
        result = `Luas Alas: ${area} cm², Volume: ${volume} cm³`;
    }

    document.getElementById('geometry-result').textContent = result;
});

function showSection(sectionId) {
    document.getElementById('bmi-section').classList.add('hidden');
    document.getElementById('fibonacci-section').classList.add('hidden');
    document.getElementById('geometry-section').classList.add('hidden');
    document.getElementById(sectionId).classList.remove('hidden');
}
